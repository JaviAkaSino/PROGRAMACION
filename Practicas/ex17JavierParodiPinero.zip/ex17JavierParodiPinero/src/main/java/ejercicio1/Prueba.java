package ejercicio1;

/**
 *
 * @author javiakasino
 */
public class Prueba {

    public static void main(String[] args) {

        Baraja b = new Baraja();
        
        b.imprimirBaraja();
        System.out.println("Número de cartas: " + b.numeroCartas());

    }
    
}
