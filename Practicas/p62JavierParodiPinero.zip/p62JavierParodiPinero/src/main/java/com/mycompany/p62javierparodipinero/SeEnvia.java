package com.mycompany.p62javierparodipinero;

/**
 *
 * @author javiakasino
 */
public interface SeEnvia {

    //Por defecto, es public y abstract
    void enviar(String direccion);

}
