package com.mycompany.p62javierparodipinero;

/**
 *
 * @author javiakasino
 */
public interface SeDescarga {

    void descargar();

}
