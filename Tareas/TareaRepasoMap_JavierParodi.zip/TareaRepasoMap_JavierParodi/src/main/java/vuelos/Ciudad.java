/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vuelos;

/**
 *
 * @author JaviA
 */
public enum Ciudad {

    MÁLAGA, SEVILLA, GRANADA, MADRID, BARCELONA, BILBAO, SANTIAGO_DE_COMPOSTELA, MALLORCA, TENERIFE, LAS_PALMAS_DE_GRAN_CANARIA, MUNICH, PARIS, AMSTERDAM, LONDRES, DUBLIN;

}
